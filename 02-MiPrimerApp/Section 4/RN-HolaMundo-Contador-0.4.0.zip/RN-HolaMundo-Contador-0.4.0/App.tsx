import React from 'react';
// import { HolaMundoScreen } from './src/screens/HolaMundoScreen';
import { ContadorScreen } from './src/screens/ContadorScreen';

export const App = () => {


  return (
    // <HolaMundoScreen />
    <ContadorScreen />
  )
}
