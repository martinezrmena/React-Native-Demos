import React from 'react'
import { Text, View } from 'react-native'

export const MapScreen = () => {
    return (
        <View>
            <Text>MapScreen</Text>
        </View>
    )
}
