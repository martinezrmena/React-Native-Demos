

export interface MenuItem {
    name: string;
    icon: string;
    component: string;
}